#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sys/time.h>
#include "util.h"
#include "Matriz.h"


using namespace std;

vector<int> buscar_col_dis( vector<vector<int> > &datos)
{
    vector<int> res;
    for(int c = 0; c < datos[0].size(); c++ ) //ya que  todos tienen la misma cantidad de cols
    {
        bool distintos = false;
        for(int f = 0; f < datos.size() -1 ; f++)
        {
            if(datos[f][c] != datos[f+1][c])
            {
                distintos = true;
                break;
            }
        }
        if(distintos) {res.push_back(c);}
    }

    return res;
}


int main(int argc, char *argv[]) {


	ifstream entrada(argv[1],std::ifstream::in); //toma el archivo test.in con el path , k, alpha, K

    string nada;

    getline(entrada, nada); //no me importa son los "pixels 1, 2..."

    vector<vector<int> > datos;


    for(string imagenes; getline(entrada, imagenes); )
    {

        vector<string> Imagen1Vector = separarComa(imagenes);

        vector<int> cadaImagen;

        for(int i=0;i<Imagen1Vector.size();i++)
        {
           cadaImagen.push_back(string_to_type<int>(Imagen1Vector[i]));
        }

        datos.push_back(cadaImagen);
    }


    vector<int> colsdis = buscar_col_dis(datos);

        ofstream fs("trainlimpio.csv"); 

/*
         fs << label << ",";

        for(int c = 0; c < colsdis.size(); i++)
        {
         if(c != colsdis.size() - 1)
            {
                fs << pixel << colsdis[c] << ",";
            }
            else
            {
               fs << pixel  << colsdis[c] << endl;
            } 
        }
*/

        for(int f = 0; f < datos.size(); f++)
        {
             for(int c = 0; c < colsdis.size(); c++ )
            { 
            
                if(c != colsdis.size() - 1)
                {
                    fs << datos[f][colsdis[c]] << ",";
                }
                else
                {
                   fs << datos[f][colsdis[c]] << endl;
                } 
            }
        }

        fs.close();
}
