#include <iostream>
#include <fstream>
#include <random>

using namespace std;

int main()
{
	ofstream outputFile;
	outputFile.open("instancia4", ios::app);

	unsigned int a = 0;
	unsigned int b = 0;
	double maxRad = 0;
	double minRad = 0;
	double tempMin = 0;
	double tempMax = 0;
	double h = 0;
	unsigned int sanguijuelas;

	cout<<"Ancho: ";
	cin>>a;
	cout<<"Alto: ";
	cin>>b;
	cout<<"Granularidad: ";
	cin>>h;
	cout<<"Cantidad de Sanguijuelas: ";
	cin>>sanguijuelas;
	cout<<"Radio minimo: ";
	cin>>minRad;
	cout<<"Radio maximo: ";
	cin>>maxRad;
	cout<<"Temperatura minima: ";
	cin>>tempMin;
	cout<<"Temperatura maxima: ";
	cin>>tempMax;


	std::uniform_real_distribution<double> distRad(minRad, maxRad);
	std::uniform_real_distribution<double> distPosX(0, a);
	std::uniform_real_distribution<double> distPosY(0, b);
	std::uniform_real_distribution<double> distTemp(tempMin, tempMax);

    std::mt19937 rng; 
    rng.seed(std::random_device{}()); 

    outputFile<<a<<" "<<b<<" "<<h<<" "<<sanguijuelas<<endl;
    for(int i = 0; i < sanguijuelas; i++)
    	outputFile<<distPosX(rng)<<" "<<distPosY(rng)<<" "<<distRad(rng)<<" "<<distTemp(rng)<<endl;


	return 0;
}